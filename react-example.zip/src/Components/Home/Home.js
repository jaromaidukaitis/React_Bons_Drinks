import React, {Component} from 'react';
import logo from '../../logo.svg';
import '../../App.css';

class Home extends Component {
	render() {
		return (
			<>
				<h2>Contato</h2>
				<div>
					<img src={logo} alt="" />
					<form action="">
						<label for="name">Nome</label>
						<input type="text" name="name" id="formName" />
						<label for="email">Email</label>
						<input type="email" name="email" id="formEmail" />
						<label for="message">Mensagem</label>
						<textarea name="message" id="formMessage" cols="30" rows="10" />
					</form>
				</div>
			</>
		);
	}
}

export default Home;
