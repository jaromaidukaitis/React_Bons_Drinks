import React, {Component} from 'react';

export default class Footer extends Component {
	render() {
		return (
			<footer>
				<p>Resilia 2020</p>
				<p>Alguns recursos reservados</p>
			</footer>
		);
	}
}
